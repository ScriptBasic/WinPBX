// Phoenix generated include file.
// Used by "TBS.rc"

// NOTE: Code may be modified or placed anywhere in a file except
//       inside a >>PHNX_BEGIN_XXX and >>PHNX_END_XXX pair of tags.
//       The >>PHNX_XXX_LOAD code block is programmer accessible, and is
//       only modified when a project is packaged as a custom control.
//       DO NOT remove the >>PHNX_BEGIN_XXX/>>PHNX_END_XXX tags.
//       The code generator modifies tagged blocks on every build.

// >>PHNX_BEGIN_DECLARES
//========================================================================================
////////////////////////////////////////////////////////////////////////////////
//
//  Manifest Resource
//

#define CREATEPROCESS_MANIFEST_RESOURCE_ID      1
#define RT_MANIFEST                             24

////////////////////////////////////////////////////////////////////////////////
//
//  Layout Rules
//

// WIDGET = CONTROL
// There are 8 parts: left, top, right, bottom, width, height widget and group.
// There are 6 metrics: left, top, right, bottom, width and height.
// There are 4 sides: left, top, right and bottom.
#define LEFT        0       // Left side of widget
#define TOP         1       // Top side of widget
#define RIGHT       2       // Right side of widget
#define BOTTOM      3       // Bottom side of widget
#define WIDTH       4       // Width of widget
#define HEIGHT      5       // Height of widget
#define WIDGET      6       // Group(one widget)
#define GROUP       7       // Group(two widgets acting as limits for a range of widgets)

// Action
#define STRETCH     0       // Metric should be stretched
#define MOVE        1       // Widget should be moved
#define VCENTER     2       // Vertically center widget/group
#define HCENTER     3       // Horizontally center widget/group
#define LIMITS      5       // Specifies minimum and maximum control size


////////////////////////////////////////////////////////////////////////////////
//
//  Control string and layout tables
//

// Form1 tooltips/layout

#define IDD_FORM1                               100
#define IDC_FORM1_STATUSBAR1                    101
#define IDC_FORM1_WMINAMESPACESCOMBOBOX         104
#define IDC_FORM1_WMICLASSESCOMBOBOX            105
#define IDC_FORM1_EDIT1                         106
#define IDC_FORM1_WMINAMESPACELABEL             107
#define IDC_FORM1_WMICLASSLABEL                 108
//========================================================================================
// >>PHNX_END_DECLARES
